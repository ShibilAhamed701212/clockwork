
import typer
from clockwork.scanner.scanner import scan_repository
from clockwork.context.context_engine import load_context
from clockwork.rules.rule_engine import verify_rules

app = typer.Typer(help="Clockwork repository intelligence CLI")

@app.command()
def init():
    print("Initializing Clockwork...")
    print("Create .clockwork directory and base files")

@app.command()
def scan():
    print("Scanning repository...")
    scan_repository(".")

@app.command()
def verify():
    print("Running verification pipeline...")
    verify_rules()

@app.command()
def context():
    print("Loading context...")
    load_context()

if __name__ == "__main__":
    app()
