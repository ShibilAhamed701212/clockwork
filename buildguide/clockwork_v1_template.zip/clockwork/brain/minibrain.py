
class MiniBrain:

    def analyze_change(self, context, repo_diff, rules):
        return {
            "status": "VALID",
            "confidence": 0.9,
            "explanation": "No issues detected."
        }
