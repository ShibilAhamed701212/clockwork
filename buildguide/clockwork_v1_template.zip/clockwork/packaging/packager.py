
import zipfile, os

def create_package():
    package_name = "project.clockwork"

    with zipfile.ZipFile(package_name, "w") as z:
        for root, dirs, files in os.walk(".clockwork"):
            for f in files:
                z.write(os.path.join(root, f))

    print("Package created:", package_name)
