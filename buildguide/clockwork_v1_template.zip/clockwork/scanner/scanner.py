
import os, json

def scan_repository(root):
    repo_map = {}
    for path, dirs, files in os.walk(root):
        repo_map[path] = files

    os.makedirs(".clockwork", exist_ok=True)
    with open(".clockwork/repo_map.json", "w") as f:
        json.dump(repo_map, f, indent=2)

    print("Repository scan complete.")
