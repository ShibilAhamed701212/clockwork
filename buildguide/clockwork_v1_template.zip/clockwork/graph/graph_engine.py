
def build_graph():
    print("Building repository knowledge graph...")
