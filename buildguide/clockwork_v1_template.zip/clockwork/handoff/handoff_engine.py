
import json, os

def generate_handoff():
    data = {
        "summary": "Example project",
        "next_task": "Implement feature X"
    }

    os.makedirs(".clockwork/handoff", exist_ok=True)

    with open(".clockwork/handoff/handoff.json", "w") as f:
        json.dump(data, f, indent=2)

    print("Handoff generated.")
