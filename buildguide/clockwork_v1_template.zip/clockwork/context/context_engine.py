
import yaml, os

CONTEXT_FILE = ".clockwork/context.yaml"

def load_context():
    if not os.path.exists(CONTEXT_FILE):
        print("Context file not found. Run clockwork init.")
        return {}

    with open(CONTEXT_FILE) as f:
        context = yaml.safe_load(f)

    print("Context loaded:", context)
    return context
