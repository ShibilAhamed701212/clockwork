
# Clockwork

Clockwork is a local-first repository intelligence and AI agent coordination system.

## Features
- Repository scanning
- Context persistence
- Rule enforcement
- Verification engine (Clockwork Brain)
- Agent handoff generation
- Portable project intelligence packaging
- Knowledge graph of the repository

## Quick Start

```bash
pip install -e .
clockwork init
clockwork scan
clockwork verify
```
